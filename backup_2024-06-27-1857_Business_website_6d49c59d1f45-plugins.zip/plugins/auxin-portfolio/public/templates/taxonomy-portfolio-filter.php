<?php /* Loops through all portfolio, taxes, .. and display posts */

/**
 * The template for displaying taxonomies
 *
 * 
 * @package    Auxin
 * @license    LICENSE.txt
 * @author     averta
 * @link       http://averta.net/phlox/
 * @copyright  (c) 2010-2022 averta
*/
include 'taxonomy-portfolio-cat.php';
