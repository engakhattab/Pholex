<?php get_header(); ?>
This is a content
<?php get_search_form(); ?>
<?php get_sidebar(); ?>

<?php get_footer(); ?>