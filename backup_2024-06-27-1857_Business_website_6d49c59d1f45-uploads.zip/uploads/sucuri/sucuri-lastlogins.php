<?php exit(0); ?>
{"user_id":1,"user_login":"Abdo","user_remoteaddr":"127.0.0.1","user_hostname":"DESKTOP-BQJUS77","user_lastlogin":"2024-06-27 17:56:53"}
